class PermissionError:
    ACCESS_SUCCESS = ''
    ACCESS_ERROR = 'Доступ запрещен'
