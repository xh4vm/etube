class TokenError:
    INVALIDED_SIGNATURE_ERROR = 'Сигнатура не совпадает'
    EXPIRED_SIGNATURE_ERROR = 'Срок жизни токена прошел'
    DECODE_ERROR = 'Не является токеном'
    FORMAT_ERROR = 'Неверный формат токена'
